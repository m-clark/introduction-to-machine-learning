# intro2MachineLearning
Documents regarding an introduction to machine learning workshop
